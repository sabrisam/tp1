

//Nœud contenant un int
	public class Cle
	{
		String  valeur;
		Cle prochain;
		ListValeur listVal;

		public Cle(String v, Cle p)
		{
			
			valeur= v; 
			prochain = p;
			listVal=new ListValeur();

		}

		public Cle(String v,String m,int f, Cle p)
		{
			
			valeur= v; 
			prochain = p;
			listVal=new ListValeur();
			listVal.ajoutFin(m,f);
			

		}


	}
