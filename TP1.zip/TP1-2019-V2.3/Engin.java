
import java.io.File;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;


public class Engin{

	Index index=new Index();
	
	public void indexer(String filename){

		// verifier si filename est un repertoire ou fichier
		String curDir =System.getProperty("user.dir");
		File file = new File(curDir+"/"+filename);
		if (file.isDirectory()){ 
			//liste des fichiers dans le repertoire choisi
			String[] files = file.list();
			indexerDir(curDir+"/"+filename,files);
			}
		//si fichier
		else indexerFile(filename);

		
    }



	
   	//indexer fichier
	public void indexerFile(String filename){
	System.out.println("indexing ..."+filename);
	String[] mots=readFile(filename+".txt");
	index.inserer(filename,mots);
		
		
	}

	//indexer la liste de fichiers du repertoire choisi
	public void indexerDir(String path,String[] filelist){
		
		for ( int i=0; i<filelist.length; i++ )
			{
				
				System.out.println("indexing ..."+"/"+path+"/"+filelist[i]);

				String[] mots=readFile(path+"/"+filelist[i]);
				index.inserer(filelist[i].substring(0,filelist[i].length()-4),mots);

				
			}

	
		
	}
	
	// Generer l'index Inverse
	public void indexerInv(){
		System.out.println("inverse indexing ...");
		index.inverser();

	} 
	
	// Afficher index et inverse index	
	public void afficher(){
		System.out.println("afficher ...");
		index.afficher();
	}
	
	
	 public void rechercher(String requette){
		System.out.println("rechercher ..."+requette);
		String[] req;
		req=requette.split(" ");
		index.rechercher(req);
	} 

	// lit le fichier et retourne les mot contenu dans tableau
	public String[] readFile(String filename){
		System.out.println("indexing ..."+filename);
		String line="";
        String lines="";
        
        String [] temparray;
		try {
			FileInputStream file = new FileInputStream(filename); 
			
			BufferedReader br = new BufferedReader(new InputStreamReader(file));
		
			while ((line = br.readLine()) != null) {
			lines=lines+" "+line;
			line="";
			}   
			
		} catch(Exception e) {e.printStackTrace(); }

			

		// nettoie les lignes lues.
		lines=lines.replace(",","");
		lines=lines.replace("d'"," ");
		lines=lines.replace("l'"," ");
		lines=lines.replace(".","");
		lines=lines.replace(":","");
		lines=lines.replace(";","");
		lines=lines.replace("(","");
		lines=lines.replace(")",""); 
		lines=lines.replace("/"," "); 
		lines=lines.replace("  "," "); 

		
		lines=lines.substring(1);
		lines=lines.toLowerCase();
		System.out.println(lines);	
		temparray=lines.split(" ");
		Arrays.sort(temparray);

		System.out.println(Arrays.toString(temparray));	
		return temparray;
	}
	
	


	

}