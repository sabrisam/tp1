import java.util.Arrays;

//Entête contenant une référence
	public class ListValeur
	{
        String Name;
        Data premier;
        
        // ajouter undoc a la fin
        public void ajoutFin(String v, int f)
        {	Data n = premier;
            // cas 1: aucun autre élément ajouté
            if (premier == null) premier = new Data(v,f,null);
            // cas 2: il y a déjà des éléments
            else 
            {	while (n.prochain != null) n = n.prochain;
                n.prochain = new Data(v,f,null);
            }
        }
        
        public void print() 
        {
            //if ( req==null){ String spc="";}
            Data n = premier;
            //System.out.printf("%-10s : ",Name);
            int count=0;
            while (n!=null)
            {
                int i=0;
                System.out.printf(" -> %2d %-10s ", n.vfr.freq, n.vfr.valeur );   // traitement
                count++; 
                if (count>4){  System.out.println(""); count=0;
                 System.out.printf("%-10s   ","" ); }  // traitement  // traitementSystem.out.printf("%-10s : ");   }
                n = n.prochain;
            }
            System.out.println();
        }

       
        public Data trouver(String v)  // trouver un Data de valeur v
        {   
            
            Data n = premier;
            while (n != null && !(n.vfr.valeur).equals(v))   n = n.prochain;
               // if (n != null){ return n.vfr.freq;} else {return 0;}
               return n;
        }

       public ListValeur communWith(ListValeur L){
           Data n = premier;
           //Data m = L.premier;
           ListValeur R=new ListValeur();
           while (n!=null){
               Data m=L.premier;
               while(m!=null){
                   if(n.vfr.valeur.equals(m.vfr.valeur)) R.ajoutFin(n.vfr.valeur,n.vfr.freq+m.vfr.freq);
                 m=m.prochain;
               }
             n=n.prochain;   
           }

           return R;
       }

       public void trierFreq(Data n)
            {
                if ( n.prochain==null )
                return;
                // Trier le reste
                trierFreq(n.prochain);
                
                // Insérer startIndex dans le reste
                insert(n);
           }

            // --- insérer l’él"S"ément index dans le reste qui est déjà trié
        static void insert( Data n)
            {
                //System.out.println(Arrays.toString(array));
                if (n.prochain==null) return;
                if (n.vfr.freq >=n.prochain.vfr.freq) return;
                //System.out.println("OOOOOOOOOOO");
                swap(n, n.prochain);	//array[index]>array[index+1]
                insert(n.prochain);
                //System.out.println(Arrays.toString(array));
            }
            // --------------------------------------
        static void swap( Data n, Data prochain)
            {
                String v= n.vfr.valeur;
                n.vfr.valeur=n.prochain.vfr.valeur;
                n.prochain.vfr.valeur=v;

                int  f= n.vfr.freq;
                n.vfr.freq=n.prochain.vfr.freq;
                n.prochain.vfr.freq=f;

            }


        public void show(String[] req){
            System.out.println("------------ REQUETTE ----------------");
            for(int i=0;i<req.length;i++) System.out.printf(" - "+req[i]); System.out.println();
            System.out.println("------------ RESULTATS ----------------");
            Data n = premier;
            //System.out.printf("%-10s : ",Name);
            int count=0;
            System.out.printf("                " ); 
            while (n!=null)
            {
                int i=0;
                
                System.out.printf("%2d %-10s ", n.vfr.freq, n.vfr.valeur );   // traitement
                count++; 
                if (count>4){  System.out.println(""); count=0;
                System.out.printf("                " ); }  // traitement  // traitementSystem.out.printf("%-10s : ");   }
                n = n.prochain;
            }
            System.out.println();

        }




	}

