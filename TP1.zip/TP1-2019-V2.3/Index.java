
import java.util.Arrays;

public class Index{
	
	ListCle listCle=new ListCle();
	ListCle listInvCle=new ListCle();
	
	

	public void inserer(String filename,String[] mots){
		System.out.println("I received "+filename);
		listCle.ajoutFin(filename);
		listCle.print();
		Cle n=listCle.trouver(filename);
		if (n!=null) fillist(n.listVal,mots);
		System.out.println(Arrays.toString(mots));
		n.listVal.print();
		

	
		
	}

	public void fillist(ListValeur list,String[] lesmots){

			for(int i=0; i<lesmots.length;i++){
				Data n = list.trouver(lesmots[i]);
				if(n==null) list.ajoutFin(lesmots[i],1);
				else n.vfr.freq++;
			}	

	}
	public void inverser(){
		System.out.println("Inversing index structure ........................");
		//System.out.println(n.valeur +" "+m.vfr.valeur+" "+m.vfr.freq);
		listCle.print();
		Cle n=listCle.premier;
		Cle d;
		while(n!=null)
			{	Data m=n.listVal.premier;
				while(m!=null)
				{
					//verifie si la cle exist deja
					d = listInvCle.trouver(m.vfr.valeur) ;
					if(d==null) { 
						// cree une nouvelle cle
						listInvCle.ajoutFin(m.vfr.valeur,n.valeur,m.vfr.freq);
					}else { 
							//verifie si loc existe deja
							Data e=d.listVal.trouver(n.valeur) ;
							// si doc n existe pas on cree un 
							if(e==null) d.listVal.ajoutFin(n.valeur,m.vfr.freq);
							//si le doc existe on ajoute la frequence a l ancienne
							else e.vfr.freq += m.vfr.freq;
						  }
										
					m=m.prochain;

				}

			n=n.prochain;
			}

			System.out.println("Printing Inversed index structure ........................");
			listInvCle.print();
	}

	public void afficher(){

		listCle.print();
		listInvCle.print();

	} 
	
	public void rechercher(String[] req){

		ListValeur[] reponses= new ListValeur[req.length];
		Cle r;

		listInvCle.print();
		for (int i=0;i<req.length;i++) {
			r=listInvCle.trouver(req[i]);
			if(r!=null) reponses[i]=r.listVal;
			}

		System.out.println(" resultats de preliminaire ..................");
		for(int i=0;i<reponses.length;i++)	reponses[i].print();
		ListValeur result= commun(reponses,reponses.length-1);
		System.out.println(" resultats de requette ..................");
		result.print();
		result.trierFreq(result.premier);
		result.show(req);
	} 

	// methde recurcive pour trouver les  elements communs aux listes reponses  
	public ListValeur commun(ListValeur[] reponses,int start){
		ListValeur result=new ListValeur();
		if(start==0) return reponses[0];
		
		while(start>0) return commun(reponses,start-1).communWith(reponses[start]);
		return result;
	}
	

}