

//Nœud contenant un int
	public class Data
	{
		ValFreq vfr;
		Data prochain;

		public Data(String v, int f, Data p)
		{
			vfr = new ValFreq();
			vfr.valeur = v; vfr.freq = f;
			prochain = p;
		}
	}
