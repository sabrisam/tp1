echo c javac
D:\jdk1.8.0_191\bin\javac %1
