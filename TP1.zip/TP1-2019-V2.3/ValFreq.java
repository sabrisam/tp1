public class ValFreq{
    public String valeur;
    public int freq;

    public String toString(){
        return this.valeur+"-"+this.freq;
    }
	public void reset(){
        this.freq=0;
    }
}