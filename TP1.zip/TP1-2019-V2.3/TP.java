﻿import java.util.Arrays;
import java.util.Scanner;

public class TP{

    public static Engin engin = new Engin();

    public static void main(String[] args){
        

        //************************************************************************** 
        //======================= menu ========================
		String cmd;
		boolean flag=true;
		//int res = 0;
        Scanner input = new Scanner (System.in);
		do
		 {   //loop d attente des entees utilisateur
			System.out.print("Commandes: indexer, inverser, afficher ou rechercher.");
			System.out.print("Entrer une commande: ");
			cmd = input.nextLine();
			if(cmd.equals("indexer")){
				System.out.print("Entrer nom du ficher sans extension txt ou un repertoire: ");
				cmd = input.nextLine();
			
				try{
					engin.indexer(cmd);
					
				} catch(Exception e) { e.printStackTrace();}
		
				}
			else if(cmd.equals("inverser")){
			    
				try{
					engin.indexerInv();
				} catch(Exception e) { e.printStackTrace();}
		
			}
			else if(cmd.equals("afficher")){
				
				try{
					engin.afficher();
				} catch(Exception e) { e.printStackTrace();}
				
			}else if(cmd.equals("rechercher")){
					System.out.print("Entrer le mot ou les mot a rechercher separés par un espace: ");
					cmd = input.nextLine();
				
				try{engin.rechercher(cmd);
				} catch(Exception e) { e.printStackTrace();} 
			}
			 
			//cmd = q ou cmd= ENTER pour quiter
			else if(cmd.equals("q")||cmd.equals("") )
			{
				flag =false;
				input.close();
			}
			else
				flag= true;
		} while(flag);
		
		
		//======================= fin menu ========================
        //************************************************************************* *


        
    }


    // methode pour effacer l ecran
    public final static void clearConsole()
		{
			try
			{
				final String os = System.getProperty("os.name");

				if (os.contains("Windows"))
				{
					Runtime.getRuntime().exec("cls");
				}
				else
				{
					Runtime.getRuntime().exec("clear");
				}
			}
			catch (final Exception e)
			{
				//  Handle any exceptions.
			}
		}


    
}