//Entête contenant une référence
public class ListCle
{
     
     Cle premier;
    
    // ajouter undoc a la fin
    public void ajoutFin(String v)
    {	Cle n = premier;
        // si pas de cle deja d'ajoutée
        if (premier == null) premier = new Cle(v,null);
        // S'il y a déjà des Cles
        else 
        {	while (n.prochain != null) n = n.prochain;
            n.prochain = new Cle(v,null);
        }
    }
    
    public void ajoutFin(String v,String m, int f)
    {	Cle n = premier;
        // cas 1: aucun autre élément ajouté
        if (premier == null) premier = new Cle(v,m,f,null);
        // cas 2: il y a déjà des éléments
        else 
        {	while (n.prochain != null) n = n.prochain;
            n.prochain = new Cle(v,m,f,null);
        }
    }

    public void print() 
    {
        Cle n = premier;
        //System.out.print(mot+" : ");
        //System.out.printf("%-10s : ",n.valeur);
        while (n!=null)
        {
            //System.out.print(n.valeur + " -> ");   // traitement
            System.out.printf("%-10s : " , n.valeur );   // traitement
            n.listVal.print();
            n = n.prochain;
        }
        System.out.println("");
    }

    /* public ListDoc(String m){
        this.mot=m;
    } */

    public Cle trouver(String v)  // trouver un Data de valeur v
        {   
            Cle n = premier;
            while (n != null && !(n.valeur).equals(v))   n = n.prochain;
               // if (n != null){ return n.vfr.freq;} else {return 0;}
               return n;
        }


    


   

}

